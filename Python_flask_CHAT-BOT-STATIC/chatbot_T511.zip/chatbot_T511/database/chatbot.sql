-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 29, 2023 at 11:45 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chatbot`
--

-- --------------------------------------------------------

--
-- Table structure for table `cc_admin`
--

CREATE TABLE `cc_admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_admin`
--

INSERT INTO `cc_admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cc_data`
--

CREATE TABLE `cc_data` (
  `id` int(11) NOT NULL,
  `input` varchar(200) NOT NULL,
  `output` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_data`
--

INSERT INTO `cc_data` (`id`, `input`, `output`) VALUES
(1, '', 'Hello How Can I Assist You !'),
(2, 'Can You Tell About Your College', 'About College'),
(3, 'What Are The Academic Programs?', 'Under Graduate ,  Post Graduate , Mphil, P.hd.'),
(4, 'What is The Admission Process?', 'Thank You For Interest! Please Check The Section: Requirments , Procedure'),
(5, 'What is The Fees?', 'For UG 20000/ per Sem'),
(6, 'Do You Provide Accomodation?', 'Yes College Will Give'),
(7, 'What clubs and organizations are available on campus?', 'Our college has a wide variety of clubs and organizations to choose from, including academic clubs, sports teams, cultural groups, and more. You can find a complete list on our website or by visiting our student activities office.'),
(8, 'What types of certificates can I obtain from the university?', 'Fees Structure, Bonafide, Attendence.'),
(9, 'How can I get involved in activities at the university?', 'You can get involved in activities at the university by joining student clubs and organizations, attending campus events, participating in intramural sports, and volunteering with community organizations. You can find information on activities and events on the university''s website, through social media, or by visiting the student activities office.'),
(10, 'What types of cultural activities are available at the university?', 'The types of cultural activities available at a university may vary depending on the school and location. Some common cultural activities include cultural festivals, music and dance performances, art exhibits, and guest speaker events.');

-- --------------------------------------------------------

--
-- Table structure for table `cc_register`
--

CREATE TABLE `cc_register` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `location` varchar(30) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `create_date` varchar(20) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_register`
--

INSERT INTO `cc_register` (`id`, `name`, `mobile`, `email`, `location`, `uname`, `pass`, `create_date`, `otp`, `status`) VALUES
(1, 'Vijay', 9638527415, 'vijay@gmail.com', 'Trichy', 'vijay', '1234', '', '', 0);
